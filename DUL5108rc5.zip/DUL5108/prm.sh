﻿echo "It's recommended that you can use JDK 1.8 or higher version"
echo "Download latest JDK http://www.oracle.com/technetwork/java/javase/downloads/index.html"
echo "find user guide here:http://zcdn.parnassusdata.com/prm04.pdf"
echo "软件使用教程:http://zcdn.parnassusdata.com/prm03.pdf"
echo "this is a gui program , so at least you should enable X11 Display on linux , for example you can run xclock or gnome-terminal"
echo "这是一个GUI程序，当在Linux上使用时，确保能启动远程图形化桌面，例如至少你应当能启动xclock或gnome-terminal"
echo "any error please check ./prm.log"
echo "任何问题请先检查软件目录下的prm.log"

java -Dfile.encoding=UTF-8 -jar prm.jar 1>>prm.log 2>&1

