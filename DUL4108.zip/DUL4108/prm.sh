echo "It's recommended that you can use JDK 1.6 or higher version"
echo "Download latest JDK http://www.oracle.com/technetwork/java/javase/downloads/index.html"
java -Xms1024M -jar prm.jar 1>>prm.log 2>&1

